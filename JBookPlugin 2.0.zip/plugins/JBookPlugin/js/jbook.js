!function ($) {

  var register = function(){
    $(document).on("click", ".app-search-cancel", onAppSearchCancelHandler);
  }
    
  var onAppSearchCancelHandler = function(event){
    $(".app-search-field").val("");
    $(".app-search-submit").click();
  }
  
  // ------------------------------------------
  //  DOM READY CODE
  // ------------------------------------------
  
  $(document).ready(function() {
    register();
  });

}(window.jQuery);

